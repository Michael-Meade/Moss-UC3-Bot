require 'rgpg'
class GPG
	def self.import_public
		system("gpg --import recipient-pubkey.gpg")
	end
	def self.encrypt
		system('gpg --encrypt  --armor -r password template/ReadMe.txt')
	end
end
