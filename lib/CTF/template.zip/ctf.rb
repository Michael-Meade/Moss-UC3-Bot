require 'json'
require 'random-word'
require 'fileutils'
require 'securerandom'
require 'base64'
require "open3"
require_relative 'gpg'
class CTF
	def self.run_gpg
		eval File.read("create_gpg/generate-gpg.rb")
		"/lib/ctf/create_gpg/secret.zip"
	end
	def self.generate_flag
		Fil
	end
	def self.xor
	end
end

#CTF.generate_python

#CTF.generate_gpg
