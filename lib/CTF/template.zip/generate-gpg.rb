require 'fileutils'
def generate_flag
	flag = RandomWord.adjs.next.to_s + rand(1..10000).to_s + RandomWord.adjs.next.to_s
	FileUtils.mkdir_p "flags/"  unless File.exists?("flags/")
	random = SecureRandom.hex
	f = File.open("flags/#{random}.json", "a")
	f.write(JSON.pretty_generate({"flag"   => flag}))
	f.close
	flag
end
def create_read_me
	flag = generate_flag
	f = File.open("template/ReadMe.txt", "w")
	f << flag
	f.close
end
def create_gpg
	system('gpg --encrypt  --armor -r password template/ReadMe.txt')
	FileUtils.rm("template/ReadMe.txt")
	system("zip -r secret.zip template")
end
create_read_me
create_gpg