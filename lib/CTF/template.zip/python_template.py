import base64
base64.b64decode('dmVyYmF0aW04NDI5YW1iaXRpb25sZXNz')